from .src.web_checker import(
    check_url_status,
)

from .src.config import(
    URL_LIST,
    CONTENT_REQUIRED,
    REQUEST_INTERVAL,
    REQUEST_TIMEOUT
)