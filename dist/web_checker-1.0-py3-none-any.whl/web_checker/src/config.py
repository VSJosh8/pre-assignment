REQUEST_INTERVAL = 2
REQUEST_TIMEOUT = 10
LOG_FILENAME = "logfile.txt"
JSON_FILENAME = "json_logfile.json"
URL_LIST = [
    "http://www.google.com", 
    "http://www.nonexistentwebsite.com", 
    "http://www.github.com/login",
    "http://www.foobar.com/login"
    ]
CONTENT_REQUIRED = ["Sign in"]